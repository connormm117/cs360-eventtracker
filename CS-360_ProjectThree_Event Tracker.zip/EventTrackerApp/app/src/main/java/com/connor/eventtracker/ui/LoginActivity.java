package com.connor.eventtracker.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.connor.eventtracker.R;
import com.connor.eventtracker.data.Repo;

public class LoginActivity extends AppCompatActivity {
    private Repo repo;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        repo = new Repo(this);

        EditText etUser = findViewById(R.id.etUser);
        EditText etPass = findViewById(R.id.etPass);
        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnRegister = findViewById(R.id.btnRegister);

        btnLogin.setOnClickListener(v -> {
            String u = etUser.getText().toString().trim();
            String p = etPass.getText().toString().trim();
            if(u.isEmpty() || p.isEmpty()){
                Toast.makeText(this, "Enter username & password", Toast.LENGTH_SHORT).show();
                return;
            }
            if(repo.verifyUser(u,p)){
                Toast.makeText(this, "Welcome, " + u, Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, DataActivity.class));
            } else {
                Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
            }
        });

        btnRegister.setOnClickListener(v -> {
            String u = etUser.getText().toString().trim();
            String p = etPass.getText().toString().trim();
            if(u.isEmpty() || p.isEmpty()){
                Toast.makeText(this, "Enter username & password", Toast.LENGTH_SHORT).show();
                return;
            }
            boolean ok = repo.createUser(u,p);
            Toast.makeText(this, ok ? "Account created. Log in!" : "Username taken.", Toast.LENGTH_SHORT).show();
        });
    }
}
