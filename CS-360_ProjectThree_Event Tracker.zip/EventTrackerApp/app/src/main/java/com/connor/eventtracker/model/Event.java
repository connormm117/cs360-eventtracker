package com.connor.eventtracker.model;

public class Event {
    public long id;
    public String title;
    public String date; // yyyy-MM-dd or similar
    public String phone;

    public Event(long id, String title, String date, String phone){
        this.id = id;
        this.title = title;
        this.date = date;
        this.phone = phone;
    }
}
