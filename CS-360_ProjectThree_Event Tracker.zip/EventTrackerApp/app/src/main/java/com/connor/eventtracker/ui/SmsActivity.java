package com.connor.eventtracker.ui;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.connor.eventtracker.R;

public class SmsActivity extends AppCompatActivity {
    private TextView tvStatus;
    private EditText etPhone, etMsg;

    private final ActivityResultLauncher<String> permLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                updateStatus();
                if(granted){
                    sendTest();
                } else {
                    Toast.makeText(this, "SMS permission denied. App will continue without alerts.", Toast.LENGTH_LONG).show();
                }
            });

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        tvStatus = findViewById(R.id.tvSmsStatus);
        etPhone  = findViewById(R.id.etPhone);
        etMsg    = findViewById(R.id.etMsg);
        Button btnReq = findViewById(R.id.btnRequestSms);
        btnReq.setOnClickListener(v -> requestSms());

        Button btnSend = findViewById(R.id.btnSendTest);
        if(btnSend != null){
            btnSend.setOnClickListener(v -> {
                if(hasSmsPermission()){
                    sendTest();
                } else {
                    requestSms();
                }
            });
        }

        updateStatus();
    }

    private void updateStatus(){
        tvStatus.setText("Permission status: " + (hasSmsPermission() ? "Granted" : "Not granted"));
    }

    private boolean hasSmsPermission(){
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestSms(){
        if(!hasSmsPermission()){
            permLauncher.launch(Manifest.permission.SEND_SMS);
        } else {
            Toast.makeText(this, "Already granted", Toast.LENGTH_SHORT).show();
        }
    }

    private void sendTest(){
        try{
            String phone = etPhone.getText().toString().trim();
            String msg = etMsg.getText().toString().trim();
            if(phone.isEmpty()){ phone = "5554"; } // default emulator phone
            if(msg.isEmpty()){ msg = "EventTracker test alert"; }
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(phone, null, msg, null, null);
            Toast.makeText(this, "Test SMS sent (if supported by device/emulator).", Toast.LENGTH_LONG).show();
        }catch(Exception ex){
            Toast.makeText(this, "Unable to send SMS here, but permission flow works.", Toast.LENGTH_LONG).show();
        }
    }
}
