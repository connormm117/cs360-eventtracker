package com.connor.eventtracker.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.connor.eventtracker.R;
import com.connor.eventtracker.model.Event;
import java.util.ArrayList;
import java.util.List;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.VH> {
    public interface Listener {
        void onDelete(Event e);
        void onEdit(Event e);
    }
    private final List<Event> data = new ArrayList<>();
    private final Listener listener;

    public EventAdapter(Listener l){ this.listener = l; }

    public void setItems(List<Event> items){
        data.clear();
        if(items != null) data.addAll(items);
        notifyDataSetChanged();
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_event, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        Event e = data.get(pos);
        h.title.setText(e.title);
        h.date.setText(e.date);
        h.btnDelete.setOnClickListener(v -> listener.onDelete(e));
        h.itemView.setOnClickListener(v -> listener.onEdit(e));
    }

    @Override public int getItemCount(){ return data.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView title, date;
        Button btnDelete;
        VH(View v){
            super(v);
            title = v.findViewById(R.id.tvItemTitle);
            date  = v.findViewById(R.id.tvItemDate);
            btnDelete = v.findViewById(R.id.btnItemDelete);
        }
    }
}
