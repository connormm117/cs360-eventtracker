package com.connor.eventtracker.ui;

import android.content.ContentValues;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.connor.eventtracker.R;
import com.connor.eventtracker.data.Repo;
import com.connor.eventtracker.model.Event;

import java.util.ArrayList;
import java.util.List;

public class DataActivity extends AppCompatActivity implements EventAdapter.Listener {
    private Repo repo;
    private EventAdapter adapter;
    private EditText etTitle, etDate;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        repo = new Repo(this);
        adapter = new EventAdapter(this);

        RecyclerView rv = findViewById(R.id.rvEvents);
        rv.setAdapter(adapter);

        etTitle = findViewById(R.id.etTitle);
        etDate  = findViewById(R.id.etDate);
        Button btnAdd = findViewById(R.id.btnAdd);
        btnAdd.setOnClickListener(v -> onAdd());

        loadData();
    }

    private void onAdd(){
        String title = etTitle.getText().toString().trim();
        String date  = etDate.getText().toString().trim();
        if(TextUtils.isEmpty(title)){
            Toast.makeText(this, "Enter title", Toast.LENGTH_SHORT).show();
            return;
        }
        long id = repo.createEvent(title, date, null, null, null);
        if(id > 0){
            etTitle.setText("");
            etDate.setText("");
            loadData();
        } else {
            Toast.makeText(this, "Failed to add", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadData(){
        Cursor c = repo.getEvents();
        List<Event> items = new ArrayList<>();
        if(c != null){
            try {
                while(c.moveToNext()){
                    long id = c.getLong(0);
                    String title = c.getString(1);
                    String date = c.getString(2);
                    String phone = c.getString(4);
                    items.add(new Event(id, title, date, phone));
                }
            } finally {
                c.close();
            }
        }
        adapter.setItems(items);
    }

    @Override public void onDelete(Event e){
        repo.deleteEvent(e.id);
        loadData();
    }

    @Override public void onEdit(Event e){
        final EditText input = new EditText(this);
        input.setText(e.title);
        new AlertDialog.Builder(this)
            .setTitle("Edit title")
            .setView(input)
            .setPositiveButton("Save", (d, which) -> {
                String newTitle = input.getText().toString().trim();
                if(!TextUtils.isEmpty(newTitle)){
                    ContentValues cv = new ContentValues();
                    cv.put("title", newTitle);
                    repo.updateEvent(e.id, cv);
                    loadData();
                }
            })
            .setNegativeButton("Cancel", null)
            .show();
    }
}
