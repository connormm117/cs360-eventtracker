# EventTracker App — Launch Plan

## Store Listing
- **Title:** EventTracker — Simple Event Reminders
- **Description (short):** Track upcoming events and get optional SMS reminders.
- **Long description:** EventTracker helps you add events, see them in a simple list, and (optionally) receive SMS alerts. Log in once, add events with a date, and manage them (add, edit, delete). SMS alerts are optional and the app works fully without them.
- **Icon:** Calendar with a small bell overlay. Flat, high-contrast, 512×512.

## Android Versions
- **Min API:** 24 (Android 7.0) or school default.
- **Target API:** Latest stable per Android Studio template.
- Rationale: modern permissions and SMS behavior are supported.

## Permissions
- **SEND_SMS:** Only requested when enabling alerts in the SMS screen.
- No audio, contacts, or location permissions.

## Monetization
- Free app, no ads (school demo). For production: one-time purchase or ad-supported with privacy-forward policy.

## QA Checklist
- Log in / Register flow tested with empty/invalid inputs.
- CRUD on events (add, edit, delete).
- SMS permission: grant/deny flows tested in emulator.
- Handles process death: DB persists across app restarts.

## Launch Steps
1. Prepare signed release (App signing by Google Play).
2. VersionCode/VersionName bump.
3. Store listing assets (icon, screenshots, description).
4. Internal testing → closed testing → production.
