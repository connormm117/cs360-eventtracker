package com.connor.eventtracker.ui;

import com.connor.eventtracker.MainActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.connor.eventtracker.R;
import com.connor.eventtracker.data.Repo;

public class LoginActivity extends AppCompatActivity {
    private Repo repo;

    @Override
    protected void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(R.layout.activity_login);
        repo = new Repo(this);

        EditText etUser = findViewById(R.id.etUser);
        EditText etPass = findViewById(R.id.etPass);
        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnRegister = findViewById(R.id.btnRegister);

        btnLogin.setOnClickListener(v -> {
            String u = etUser.getText().toString().trim();
            String p = etPass.getText().toString().trim();
            if(repo.checkLogin(u,p)){
                startActivity(new Intent(this, MainActivity.class));
                finish();
            } else {
                Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
            }
        });

        btnRegister.setOnClickListener(v -> {
            String u = etUser.getText().toString().trim();
            String p = etPass.getText().toString().trim();
            if(u.isEmpty() || p.isEmpty()){
                Toast.makeText(this, "Enter username & password", Toast.LENGTH_SHORT).show();
                return;
            }
            boolean ok = repo.createUser(u,p);
            Toast.makeText(this, ok ? "Account created. Log in!" : "Username taken.", Toast.LENGTH_SHORT).show();
        });
    }
}