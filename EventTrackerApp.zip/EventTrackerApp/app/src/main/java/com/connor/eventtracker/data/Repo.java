package com.connor.eventtracker.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class Repo {
    private final DatabaseHelper helper;

    public Repo(Context ctx) { helper = new DatabaseHelper(ctx); }

    // ---- USERS ----
    public boolean createUser(String username, String password){
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("username", username);
        cv.put("password", password); // class demo only (no hashing)
        long id = db.insert(DatabaseHelper.T_USERS, null, cv);
        return id != -1;
    }

    public boolean checkLogin(String username, String password){
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT id FROM " + DatabaseHelper.T_USERS + " WHERE username=? AND password=?",
                new String[]{username, password});
        boolean ok = c.moveToFirst();
        c.close();
        return ok;
    }

    // ---- EVENTS (CRUD) ----
    public long addEvent(String title, String date, String location, String notes, String phone){
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("title", title);
        cv.put("event_date", date);
        cv.put("location", location);
        cv.put("notes", notes);
        cv.put("phone", phone);
        return db.insert(DatabaseHelper.T_EVENTS, null, cv);
    }

    public Cursor getAllEvents(){
        SQLiteDatabase db = helper.getReadableDatabase();
        return db.rawQuery("SELECT id, title, event_date, location, phone, notified FROM " +
                DatabaseHelper.T_EVENTS + " ORDER BY event_date ASC", null);
    }

    public int updateEvent(long id, ContentValues cv){
        SQLiteDatabase db = helper.getWritableDatabase();
        return db.update(DatabaseHelper.T_EVENTS, cv, "id=?", new String[]{String.valueOf(id)});
    }

    public int deleteEvent(long id){
        SQLiteDatabase db = helper.getWritableDatabase();
        return db.delete(DatabaseHelper.T_EVENTS, "id=?", new String[]{String.valueOf(id)});
    }
}
